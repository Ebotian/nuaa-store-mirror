for p=0:10:360   %速度 取向右为正方向
x=p*3.1415926/180;
B=atan(cos(x)./(350/116.31+sin(x)));
y1=0.63191.*sin(B);%位移 右正左负
y2=-1*5.95*0.63191*sin(B+x).*sin(B).*cos(B)./cos(x);%速度 取向右为正方向
w=5.95*sin(B+x).*sin(B)./cos(x);
m1=-w.*sin(B).*cos(2.*B);
m2=-0.5.*w.*sin(2.*B).*cos(2.*B);
m3=5.95.*sin(2.*B).*cos(B)./2./(cos(x)).^2;
m4=0.5.*w.*tan(x).*sin(B).*sin(2.*B);
m5=-w.*tan(x).*cos(B).*cos(2.*B);
y3=-5.95*0.63191.*(m1+m2+m3+m4+m5);%加速度 取向右为正
disp(y3);
end
