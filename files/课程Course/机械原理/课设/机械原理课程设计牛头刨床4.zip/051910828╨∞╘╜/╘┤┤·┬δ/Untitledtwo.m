p=0:0.01:360;  %加速度 取向右为正
x=p*3.1415926/180;
B=atan(cos(x)./(350/116.31+sin(x)));
w=5.95*sin(B+x).*sin(B)./cos(x);
m1=-w.*sin(B).*cos(2.*B);
m2=-0.5.*w.*sin(2.*B).*cos(2.*B);
m3=5.95.*sin(2.*B).*cos(B)./2./(cos(x)).^2;
m4=0.5.*w.*tan(x).*sin(B).*sin(2.*B);
m5=-w.*tan(x).*cos(B).*cos(2.*B);
y=-5.95*0.63191.*(m1+m2+m3+m4+m5);
plot(x,y);